/*
  # Système d'administration et gestion des élèves

  1. Nouvelles Tables
    - `profiles`
      - Stocke les informations des utilisateurs (admin et élèves)
    - `temp_credentials`
      - Stocke les identifiants temporaires pour les élèves
    - `club_sessions`
      - Gère les sessions du club
    - `learning_progress`
      - Suit la progression des élèves
    - `learning_resources`
      - Contient les ressources d'apprentissage
    - `practice_links`
      - Liste des liens externes pour s'entraîner

  2. Security
    - Enable RLS sur toutes les tables
    - Politiques spécifiques pour admin et élèves
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid REFERENCES auth.users PRIMARY KEY,
  role text NOT NULL DEFAULT 'student',
  first_name text,
  last_name text,
  class text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_role CHECK (role IN ('admin', 'student'))
);

-- Temporary credentials
CREATE TABLE IF NOT EXISTS temp_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  temp_password text NOT NULL,
  is_used boolean DEFAULT false,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT (now() + interval '7 days')
);

-- Club sessions
CREATE TABLE IF NOT EXISTS club_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date timestamptz NOT NULL,
  description text,
  location text,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Learning progress
CREATE TABLE IF NOT EXISTS learning_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id),
  resource_id uuid,
  progress integer DEFAULT 0,
  completed boolean DEFAULT false,
  last_accessed timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Learning resources
CREATE TABLE IF NOT EXISTS learning_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  content text NOT NULL,
  category text NOT NULL,
  difficulty text NOT NULL,
  order_index integer,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Practice links
CREATE TABLE IF NOT EXISTS practice_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  url text NOT NULL,
  description text,
  category text NOT NULL,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE temp_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE club_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE practice_links ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Temp credentials policies
CREATE POLICY "Only admins can manage temp credentials"
  ON temp_credentials
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Club sessions policies
CREATE POLICY "Sessions are viewable by everyone"
  ON club_sessions FOR SELECT
  USING (true);

CREATE POLICY "Only admins can manage sessions"
  ON club_sessions
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Learning progress policies
CREATE POLICY "Users can view own progress"
  ON learning_progress FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
  ON learning_progress FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Learning resources policies
CREATE POLICY "Resources are viewable by everyone"
  ON learning_resources FOR SELECT
  USING (true);

CREATE POLICY "Only admins can manage resources"
  ON learning_resources
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Practice links policies
CREATE POLICY "Links are viewable by everyone"
  ON practice_links FOR SELECT
  USING (true);

CREATE POLICY "Only admins can manage links"
  ON practice_links
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));