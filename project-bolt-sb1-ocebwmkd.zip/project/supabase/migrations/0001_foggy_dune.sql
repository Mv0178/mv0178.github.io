/*
  # Create saved codes table

  1. New Tables
    - `saved_codes`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `code` (text)
      - `title` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `saved_codes` table
    - Add policies for users to manage their own codes
*/

CREATE TABLE IF NOT EXISTS saved_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  code text NOT NULL,
  title text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE saved_codes ENABLE ROW LEVEL SECURITY;

-- Allow users to read their own codes
CREATE POLICY "Users can read own codes"
  ON saved_codes
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow users to insert their own codes
CREATE POLICY "Users can insert own codes"
  ON saved_codes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Allow users to update their own codes
CREATE POLICY "Users can update own codes"
  ON saved_codes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);