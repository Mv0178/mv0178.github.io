import React, { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';

export default function CreateTempCredentials({ onCreated }: { onCreated: () => void }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const generateTempPassword = () => {
    return Math.random().toString(36).slice(-8);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const tempPassword = generateTempPassword();

    try {
      const { error } = await supabase
        .from('temp_credentials')
        .insert([
          {
            email,
            temp_password: tempPassword,
            created_by: user?.id
          }
        ]);

      if (error) throw error;

      alert(`Identifiants créés :\nEmail : ${email}\nMot de passe temporaire : ${tempPassword}`);
      setEmail('');
      onCreated();
    } catch (error) {
      alert("Erreur lors de la création des identifiants");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex space-x-4">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email de l'élève"
        className="rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
        required
      />
      <button
        type="submit"
        disabled={loading}
        className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50"
      >
        Créer des identifiants
      </button>
    </form>
  );
}