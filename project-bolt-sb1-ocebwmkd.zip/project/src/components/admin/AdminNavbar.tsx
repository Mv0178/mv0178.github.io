import React from 'react';
import { Link } from 'react-router-dom';
import { Users, Calendar, BookOpen, Link as LinkIcon, Settings } from 'lucide-react';

export default function AdminNavbar() {
  return (
    <nav className="bg-gray-800 text-white">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <Link to="/admin" className="font-bold text-xl">Admin</Link>
            <div className="flex space-x-4">
              <Link to="/admin/students" className="flex items-center space-x-2 hover:text-gray-300">
                <Users className="h-5 w-5" />
                <span>Élèves</span>
              </Link>
              <Link to="/admin/sessions" className="flex items-center space-x-2 hover:text-gray-300">
                <Calendar className="h-5 w-5" />
                <span>Séances</span>
              </Link>
              <Link to="/admin/resources" className="flex items-center space-x-2 hover:text-gray-300">
                <BookOpen className="h-5 w-5" />
                <span>Ressources</span>
              </Link>
              <Link to="/admin/practice" className="flex items-center space-x-2 hover:text-gray-300">
                <LinkIcon className="h-5 w-5" />
                <span>Liens</span>
              </Link>
            </div>
          </div>
          <Link to="/admin/settings" className="hover:text-gray-300">
            <Settings className="h-6 w-6" />
          </Link>
        </div>
      </div>
    </nav>
  );
}