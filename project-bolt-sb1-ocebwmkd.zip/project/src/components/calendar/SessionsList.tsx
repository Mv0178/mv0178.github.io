import React from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { MapPin, Clock } from 'lucide-react';

interface Session {
  id: string;
  date: string;
  description: string;
  location: string;
}

interface Props {
  sessions: Session[];
  loading: boolean;
}

export default function SessionsList({ sessions, loading }: Props) {
  if (loading) {
    return <div>Chargement des séances...</div>;
  }

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b">
        <h2 className="text-lg font-semibold">Prochaines séances</h2>
      </div>
      <div className="divide-y">
        {sessions.map(session => (
          <div key={session.id} className="p-4">
            <div className="font-semibold mb-2">
              {format(new Date(session.date), 'EEEE d MMMM', { locale: fr })}
            </div>
            <div className="text-sm text-gray-600 space-y-1">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2" />
                {format(new Date(session.date), 'HH:mm')}
              </div>
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                {session.location}
              </div>
            </div>
            {session.description && (
              <p className="mt-2 text-sm text-gray-600">{session.description}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}