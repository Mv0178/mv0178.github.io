import React from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';
import { fr } from 'date-fns/locale';

interface Session {
  id: string;
  date: string;
  description: string;
  location: string;
}

interface Props {
  sessions: Session[];
  loading: boolean;
}

export default function CalendarGrid({ sessions, loading }: Props) {
  const today = new Date();
  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(today);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  if (loading) {
    return <div>Chargement du calendrier...</div>;
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-4 bg-indigo-600 text-white text-center">
        <h2 className="text-xl font-semibold">
          {format(today, 'MMMM yyyy', { locale: fr })}
        </h2>
      </div>
      
      <div className="grid grid-cols-7 gap-px bg-gray-200">
        {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(day => (
          <div key={day} className="bg-gray-50 p-2 text-center text-sm font-medium">
            {day}
          </div>
        ))}
        
        {days.map(day => {
          const dayHasSession = sessions.some(session => 
            isSameDay(new Date(session.date), day)
          );

          return (
            <div
              key={day.toISOString()}
              className={`bg-white p-2 min-h-[80px] ${
                dayHasSession ? 'bg-indigo-50' : ''
              }`}
            >
              <span className="text-sm">{format(day, 'd')}</span>
              {dayHasSession && (
                <div className="mt-1">
                  <div className="text-xs bg-indigo-100 text-indigo-800 rounded px-1 py-0.5">
                    Séance prévue
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}