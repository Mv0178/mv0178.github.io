import React from 'react';

interface CodePreviewProps {
  code: string;
}

export default function CodePreview({ code }: CodePreviewProps) {
  return (
    <div className="bg-white p-4 border-l border-gray-200">
      <div className="h-full" dangerouslySetInnerHTML={{ __html: code }} />
    </div>
  );
}