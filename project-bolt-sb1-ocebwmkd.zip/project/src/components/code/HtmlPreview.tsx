import React from 'react';

interface Props {
  code: string;
}

export default function HtmlPreview({ code }: Props) {
  return (
    <div className="bg-white p-4 border rounded-lg">
      <div className="border-b pb-2 mb-2">
        <h3 className="text-sm font-medium text-gray-600">Aperçu</h3>
      </div>
      <div
        className="prose max-w-none"
        dangerouslySetInnerHTML={{ __html: code }}
      />
    </div>
  );
}