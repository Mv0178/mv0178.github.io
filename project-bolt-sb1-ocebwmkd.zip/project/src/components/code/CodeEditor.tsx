import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { saveCode } from './CodeSaver';
import HtmlPreview from './HtmlPreview';

interface Props {
  initialCode?: string;
  language?: string;
  readOnly?: boolean;
  showPreview?: boolean;
}

export default function CodeEditor({
  initialCode = '',
  language = 'html',
  readOnly = false,
  showPreview = true
}: Props) {
  const [code, setCode] = useState(initialCode);
  const { user } = useAuth();
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  useEffect(() => {
    setCode(initialCode);
  }, [initialCode]);

  const handleSave = async () => {
    if (!user) return;

    setSaveStatus('saving');
    const result = await saveCode({
      userId: user.id,
      code,
      language
    });

    setSaveStatus(result.success ? 'saved' : 'error');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const getSaveButtonText = () => {
    switch (saveStatus) {
      case 'saving': return 'Sauvegarde...';
      case 'saved': return 'Sauvegardé !';
      case 'error': return 'Erreur';
      default: return 'Sauvegarder';
    }
  };

  return (
    <div className="space-y-4">
      {user && !readOnly && (
        <button
          onClick={handleSave}
          disabled={saveStatus === 'saving'}
          className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-white ${
            saveStatus === 'saved' 
              ? 'bg-green-600' 
              : saveStatus === 'error'
                ? 'bg-red-600'
                : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          <Save className="h-4 w-4" />
          <span>{getSaveButtonText()}</span>
        </button>
      )}

      <div className={showPreview ? 'grid grid-cols-2 gap-4' : ''}>
        <div className="bg-gray-900 rounded-lg">
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full h-[400px] bg-gray-900 text-white font-mono p-4 resize-none focus:outline-none rounded-lg"
            readOnly={readOnly}
          />
        </div>
        {showPreview && language === 'html' && (
          <HtmlPreview code={code} />
        )}
      </div>
    </div>
  );
}