import React, { useState } from 'react';
import { Save } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import HtmlPreview from './HtmlPreview';

interface Props {
  initialCode?: string;
  language?: string;
  readOnly?: boolean;
}

export default function CodeEditorWithPreview({ 
  initialCode = '', 
  language = 'html',
  readOnly = false 
}: Props) {
  const [code, setCode] = useState(initialCode);
  const { user } = useAuth();

  const handleSave = async () => {
    // TODO: Implement save functionality
  };

  return (
    <div className="space-y-4">
      {user && !readOnly && (
        <button
          onClick={handleSave}
          className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          <Save className="h-4 w-4" />
          <span>Sauvegarder</span>
        </button>
      )}
      
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-900 rounded-lg">
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full h-[400px] bg-gray-900 text-white font-mono p-4 resize-none focus:outline-none rounded-lg"
            readOnly={readOnly}
          />
        </div>
        <HtmlPreview code={code} />
      </div>
    </div>
  );
}