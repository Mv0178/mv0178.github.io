import React from 'react';
import { Save, FolderOpen } from 'lucide-react';

interface CodeEditorToolbarProps {
  onSave: () => void;
  savedCodes: any[];
  onLoadCode: (code: any) => void;
  isAuthenticated: boolean;
}

export default function CodeEditorToolbar({
  onSave,
  savedCodes,
  onLoadCode,
  isAuthenticated
}: CodeEditorToolbarProps) {
  if (!isAuthenticated) {
    return (
      <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4">
        Connectez-vous pour sauvegarder votre code
      </div>
    );
  }

  return (
    <div className="flex justify-between items-center mb-4">
      <button
        onClick={onSave}
        className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
      >
        <Save className="h-4 w-4" />
        <span>Sauvegarder</span>
      </button>

      <div className="relative group">
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
          <FolderOpen className="h-4 w-4" />
          <span>Charger</span>
        </button>

        <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg hidden group-hover:block">
          {savedCodes.map((code) => (
            <button
              key={code.id}
              onClick={() => onLoadCode(code)}
              className="block w-full text-left px-4 py-2 hover:bg-gray-100"
            >
              {code.title}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}