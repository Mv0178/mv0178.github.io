import { supabase } from '../../lib/supabase';

interface SaveCodeParams {
  userId: string;
  code: string;
  language: string;
  title?: string;
}

export async function saveCode({ userId, code, language, title }: SaveCodeParams) {
  try {
    const { error } = await supabase
      .from('saved_codes')
      .insert([
        {
          user_id: userId,
          code,
          title: title || `Code ${language} - ${new Date().toLocaleString()}`,
          language
        }
      ]);

    if (error) throw error;
    return { success: true };
  } catch (error) {
    console.error('Error saving code:', error);
    return { success: false, error };
  }
}