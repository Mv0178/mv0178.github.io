import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Code2, Users, Calendar, MessageSquare, LogIn, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';

export default function Navbar() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  return (
    <nav className="bg-indigo-600 text-white p-4">
      <div className="container mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Code2 className="h-8 w-8" />
          <span className="text-xl font-bold">Club Programmation</span>
        </Link>
        <div className="flex space-x-6 items-center">
          <Link to="/" className="flex items-center space-x-1 hover:text-indigo-200">
            <Users className="h-5 w-5" />
            <span>Accueil</span>
          </Link>
          {user && (
            <Link to="/dashboard" className="flex items-center space-x-1 hover:text-indigo-200">
              <Code2 className="h-5 w-5" />
              <span>Mon Espace</span>
            </Link>
          )}
          <Link to="/#forum" className="flex items-center space-x-1 hover:text-indigo-200">
            <MessageSquare className="h-5 w-5" />
            <span>Forum</span>
          </Link>
          <Link to="/#inscription" className="flex items-center space-x-1 hover:text-indigo-200">
            <Calendar className="h-5 w-5" />
            <span>Inscription</span>
          </Link>
          {user ? (
            <button
              onClick={handleLogout}
              className="flex items-center space-x-1 hover:text-indigo-200"
            >
              <LogOut className="h-5 w-5" />
              <span>Déconnexion</span>
            </button>
          ) : (
            <Link
              to="/auth"
              className="flex items-center space-x-1 hover:text-indigo-200"
            >
              <LogIn className="h-5 w-5" />
              <span>Connexion</span>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}