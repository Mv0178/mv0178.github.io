import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Code2, FileCode, Globe, Cpu } from 'lucide-react';

const courses = [
  { path: '/learning/python', icon: FileCode, name: 'Python' },
  { path: '/learning/html', icon: Globe, name: 'HTML' },
  { path: '/learning/javascript', icon: Cpu, name: 'JavaScript' }
];

export default function LearningNavbar() {
  const location = useLocation();

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center space-x-8 h-16">
          <Link to="/learning" className="flex items-center space-x-2 font-bold text-xl text-indigo-600">
            <Code2 className="h-6 w-6" />
            <span>Apprentissage</span>
          </Link>
          <div className="flex space-x-6">
            {courses.map(({ path, icon: Icon, name }) => (
              <Link
                key={path}
                to={path}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-colors ${
                  location.pathname.startsWith(path)
                    ? 'bg-indigo-50 text-indigo-700'
                    : 'text-gray-600 hover:text-indigo-600'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{name}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}