import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Lock } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useProgress } from '../../hooks/useProgress';

interface Module {
  id: string;
  title: string;
  description: string;
  lessons: Array<{
    id: string;
    title: string;
  }>;
}

interface Props {
  modules: Module[];
  coursePath: string;
}

export default function ModuleList({ modules, coursePath }: Props) {
  const { user } = useAuth();
  const { progress } = useProgress();

  const isLessonCompleted = (moduleId: string, lessonId: string) => {
    return progress?.some(p => 
      p.module_id === moduleId && 
      p.lesson_id === lessonId && 
      p.completed
    );
  };

  return (
    <div className="space-y-6">
      {modules.map((module, index) => (
        <div key={module.id} className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">
            Module {index + 1} : {module.title}
          </h2>
          <p className="text-gray-600 mb-6">{module.description}</p>
          
          <div className="space-y-3">
            {module.lessons.map((lesson, lessonIndex) => {
              const isCompleted = isLessonCompleted(module.id, lesson.id);
              const isLocked = !user || (lessonIndex > 0 && !isLessonCompleted(module.id, module.lessons[lessonIndex - 1].id));

              return (
                <Link
                  key={lesson.id}
                  to={isLocked ? '#' : `${module.id}/${lesson.id}`}
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    isLocked
                      ? 'bg-gray-50 cursor-not-allowed'
                      : 'hover:bg-indigo-50'
                  }`}
                >
                  <div className="flex items-center">
                    <span className="text-gray-800">
                      {lessonIndex + 1}. {lesson.title}
                    </span>
                  </div>
                  {isLocked ? (
                    <Lock className="h-5 w-5 text-gray-400" />
                  ) : isCompleted ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : null}
                </Link>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}