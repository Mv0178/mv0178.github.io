import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useProgress } from '../../hooks/useProgress';
import CodeEditor from '../code/CodeEditor';

interface Lesson {
  id: string;
  title: string;
  content: string;
  exercise?: {
    instructions: string;
    initialCode: string;
    solution: string;
  };
}

interface Module {
  id: string;
  title: string;
  lessons: Lesson[];
}

interface Props {
  modules: Module[];
}

export default function LessonContent({ modules }: Props) {
  const { moduleId, lessonId } = useParams();
  const { updateProgress } = useProgress();
  
  const module = modules.find(m => m.id === moduleId);
  const lesson = module?.lessons.find(l => l.id === lessonId);

  useEffect(() => {
    if (moduleId && lessonId) {
      updateProgress(moduleId, lessonId);
    }
  }, [moduleId, lessonId]);

  if (!lesson) return <div>Leçon non trouvée</div>;

  return (
    <div className="space-y-8">
      <div className="prose max-w-none">
        <h1>{lesson.title}</h1>
        <div dangerouslySetInnerHTML={{ __html: lesson.content }} />
      </div>

      {lesson.exercise && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4">Exercice</h2>
          <p className="mb-4">{lesson.exercise.instructions}</p>
          <CodeEditor
            initialCode={lesson.exercise.initialCode}
            language="python"
            readOnly={false}
          />
        </div>
      )}
    </div>
  );
}