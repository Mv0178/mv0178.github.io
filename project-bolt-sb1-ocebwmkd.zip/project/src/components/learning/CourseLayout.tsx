import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

interface Props {
  title: string;
  description: string;
  children: React.ReactNode;
}

export default function CourseLayout({ title, description, children }: Props) {
  const location = useLocation();
  const isRoot = !location.pathname.split('/').slice(2)[1];

  return (
    <div>
      <div className="mb-8">
        {!isRoot && (
          <Link
            to=".."
            className="inline-flex items-center text-indigo-600 hover:text-indigo-700 mb-4"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Retour
          </Link>
        )}
        <h1 className="text-3xl font-bold mb-2">{title}</h1>
        <p className="text-gray-600">{description}</p>
      </div>
      {children}
    </div>
  );
}