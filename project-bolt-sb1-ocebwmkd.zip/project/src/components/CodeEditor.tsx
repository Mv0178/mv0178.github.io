import React, { useState } from 'react';

export default function CodeEditor() {
  const [code, setCode] = useState('<!-- Écrivez votre code HTML ici -->\n<h1>Bonjour!</h1>');
  
  return (
    <div className="grid grid-cols-2 gap-4 h-[500px] bg-gray-100 rounded-lg overflow-hidden">
      <div className="bg-gray-900 p-4">
        <textarea
          className="w-full h-full bg-gray-900 text-white font-mono p-4 resize-none focus:outline-none"
          value={code}
          onChange={(e) => setCode(e.target.value)}
        />
      </div>
      <div className="bg-white p-4 border-l border-gray-200">
        <div className="h-full"
          dangerouslySetInnerHTML={{ __html: code }}
        />
      </div>
    </div>
  );
}