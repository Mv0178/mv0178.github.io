import React from 'react';
import Navbar from '../components/Navbar';
import CodeEditor from '../components/code/CodeEditor';
import RegistrationForm from '../components/RegistrationForm';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <section id="accueil" className="relative h-[500px] bg-cover bg-center" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1516116216624-53e697fedbea?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")'
      }}>
        <div className="absolute inset-0 bg-black bg-opacity-60">
          <div className="container mx-auto h-full flex items-center justify-center text-center text-white px-4">
            <div>
              <h1 className="text-5xl font-bold mb-4">Club Programmation</h1>
              <p className="text-xl mb-8">Découvrez le monde passionnant du code avec nous !</p>
              <a href="#inscription" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-lg">
                Rejoignez-nous
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Informations */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Informations Pratiques</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Quand ?</h3>
              <p>Tous les mercredis<br />14h - 16h</p>
            </div>
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Où ?</h3>
              <p>Salle informatique B12<br />Collège Tech</p>
            </div>
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Avec qui ?</h3>
              <p>M. Martin<br />Professeur d'informatique</p>
            </div>
          </div>
        </div>
      </section>

      {/* Code Editor Section */}
      <section id="coding" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Éditeur de Code</h2>
          <CodeEditor />
        </div>
      </section>

      {/* Forum Section */}
      <section id="forum" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Forum d'Échange</h2>
          <div className="bg-gray-50 p-8 rounded-lg text-center">
            <p className="text-gray-600">Le forum sera bientôt disponible...</p>
          </div>
        </div>
      </section>

      {/* Registration Section */}
      <section id="inscription" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Inscription</h2>
          <RegistrationForm />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2024 Club Programmation. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
}