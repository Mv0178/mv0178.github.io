import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import AdminNavbar from '../../components/admin/AdminNavbar';
import StudentList from '../../components/admin/StudentList';
import CreateTempCredentials from '../../components/admin/CreateTempCredentials';

export default function StudentManagement() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'student');
    
    if (!error && data) {
      setStudents(data);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminNavbar />
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Gestion des élèves</h1>
          <CreateTempCredentials onCreated={loadStudents} />
        </div>
        <StudentList students={students} loading={loading} onUpdate={loadStudents} />
      </main>
    </div>
  );
}