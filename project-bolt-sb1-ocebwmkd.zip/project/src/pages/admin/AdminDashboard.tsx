import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import AdminNavbar from '../../components/admin/AdminNavbar';
import AdminStats from '../../components/admin/AdminStats';

export default function AdminDashboard() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (!user || profile?.role !== 'admin') {
      navigate('/auth');
    }
  }, [user, profile, navigate]);

  if (!user || profile?.role !== 'admin') return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminNavbar />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Tableau de bord administrateur</h1>
        <AdminStats />
      </main>
    </div>
  );
}