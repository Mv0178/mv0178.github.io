import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LearningNavbar from '../../components/learning/LearningNavbar';
import LearningHome from './LearningHome';
import PythonCourse from './courses/PythonCourse';
import HtmlCourse from './courses/HtmlCourse';
import JavaScriptCourse from './courses/JavaScriptCourse';

export default function LearningPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <LearningNavbar />
      <main className="container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<LearningHome />} />
          <Route path="/python/*" element={<PythonCourse />} />
          <Route path="/html/*" element={<HtmlCourse />} />
          <Route path="/javascript/*" element={<JavaScriptCourse />} />
        </Routes>
      </main>
    </div>
  );
}