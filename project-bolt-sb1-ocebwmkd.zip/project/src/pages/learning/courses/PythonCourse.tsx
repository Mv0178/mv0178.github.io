import React from 'react';
import { Routes, Route } from 'react-router-dom';
import CourseLayout from '../../../components/learning/CourseLayout';
import ModuleList from '../../../components/learning/ModuleList';
import LessonContent from '../../../components/learning/LessonContent';
import { pythonModules } from '../../../data/pythonCourse';

export default function PythonCourse() {
  return (
    <CourseLayout title="Python" description="Apprenez à programmer en Python">
      <Routes>
        <Route index element={<ModuleList modules={pythonModules} coursePath="python" />} />
        <Route path=":moduleId/:lessonId" element={<LessonContent modules={pythonModules} />} />
      </Routes>
    </CourseLayout>
  );
}