import React from 'react';
import { Routes, Route } from 'react-router-dom';
import CourseLayout from '../../../components/learning/CourseLayout';
import ModuleList from '../../../components/learning/ModuleList';
import LessonContent from '../../../components/learning/LessonContent';
import { javascriptModules } from '../../../data/javascriptCourse';

export default function JavaScriptCourse() {
  return (
    <CourseLayout title="JavaScript" description="Apprenez la programmation web avec JavaScript">
      <Routes>
        <Route index element={<ModuleList modules={javascriptModules} coursePath="javascript" />} />
        <Route path=":moduleId/:lessonId" element={<LessonContent modules={javascriptModules} />} />
      </Routes>
    </CourseLayout>
  );
}