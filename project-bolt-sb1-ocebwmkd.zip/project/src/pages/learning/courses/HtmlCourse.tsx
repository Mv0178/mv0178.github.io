import React from 'react';
import { Routes, Route } from 'react-router-dom';
import CourseLayout from '../../../components/learning/CourseLayout';
import ModuleList from '../../../components/learning/ModuleList';
import LessonContent from '../../../components/learning/LessonContent';
import { htmlModules } from '../../../data/htmlCourse';

export default function HtmlCourse() {
  return (
    <CourseLayout title="HTML" description="Apprenez à créer des pages web avec HTML">
      <Routes>
        <Route index element={<ModuleList modules={htmlModules} coursePath="html" />} />
        <Route path=":moduleId/:lessonId" element={<LessonContent modules={htmlModules} />} />
      </Routes>
    </CourseLayout>
  );
}