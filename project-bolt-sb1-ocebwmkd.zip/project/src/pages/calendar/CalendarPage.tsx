import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import Navbar from '../../components/Navbar';
import CalendarGrid from '../../components/calendar/CalendarGrid';
import SessionsList from '../../components/calendar/SessionsList';
import { useAuth } from '../../hooks/useAuth';

export default function CalendarPage() {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const { profile } = useAuth();

  useEffect(() => {
    loadSessions();
  }, []);

  const loadSessions = async () => {
    const { data, error } = await supabase
      .from('club_sessions')
      .select('*')
      .order('date', { ascending: true });
    
    if (!error && data) {
      setSessions(data);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Calendrier des séances</h1>
          {profile?.role === 'admin' && (
            <button
              onClick={() => {/* TODO: Add session modal */}}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
            >
              Ajouter une séance
            </button>
          )}
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <CalendarGrid sessions={sessions} loading={loading} />
          </div>
          <div>
            <SessionsList sessions={sessions} loading={loading} />
          </div>
        </div>
      </main>
    </div>
  );
}