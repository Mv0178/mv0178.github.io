import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

interface Progress {
  id: string;
  user_id: string;
  module_id: string;
  lesson_id: string;
  completed: boolean;
  last_accessed: string;
}

export function useProgress() {
  const { user } = useAuth();
  const [progress, setProgress] = useState<Progress[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadProgress();
    }
  }, [user]);

  const loadProgress = async () => {
    const { data, error } = await supabase
      .from('learning_progress')
      .select('*')
      .eq('user_id', user?.id);

    if (!error && data) {
      setProgress(data);
    }
    setLoading(false);
  };

  const updateProgress = async (moduleId: string, lessonId: string) => {
    if (!user) return;

    const { error } = await supabase
      .from('learning_progress')
      .upsert({
        user_id: user.id,
        module_id: moduleId,
        lesson_id: lessonId,
        last_accessed: new Date().toISOString()
      });

    if (!error) {
      loadProgress();
    }
  };

  return { progress, loading, updateProgress };
}