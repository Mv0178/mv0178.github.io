import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';

// Pages
import HomePage from './pages/HomePage';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import AdminDashboard from './pages/admin/AdminDashboard';
import StudentManagement from './pages/admin/StudentManagement';
import LearningPage from './pages/learning/LearningPage';
import PracticePage from './pages/practice/PracticePage';
import CalendarPage from './pages/calendar/CalendarPage';

function App() {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return <div>Chargement...</div>;
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/auth" element={!user ? <AuthPage /> : <Navigate to="/dashboard" />} />

        {/* Protected student routes */}
        <Route 
          path="/dashboard" 
          element={user ? <DashboardPage /> : <Navigate to="/auth" />} 
        />
        <Route 
          path="/learning/*" 
          element={user ? <LearningPage /> : <Navigate to="/auth" />} 
        />
        <Route 
          path="/practice" 
          element={user ? <PracticePage /> : <Navigate to="/auth" />} 
        />
        <Route 
          path="/calendar" 
          element={user ? <CalendarPage /> : <Navigate to="/auth" />} 
        />

        {/* Admin routes */}
        <Route 
          path="/admin" 
          element={
            user && profile?.role === 'admin' 
              ? <AdminDashboard /> 
              : <Navigate to="/auth" />
          } 
        />
        <Route 
          path="/admin/*" 
          element={
            user && profile?.role === 'admin' 
              ? <AdminDashboard /> 
              : <Navigate to="/auth" />
          } 
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;