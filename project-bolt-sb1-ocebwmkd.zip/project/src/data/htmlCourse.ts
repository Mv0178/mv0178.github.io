// Add more lessons to the existing HTML course
export const htmlModules = [
  // ... existing modules ...
  {
    id: 'forms',
    title: 'Formulaires HTML',
    description: 'Apprenez à créer des formulaires interactifs',
    lessons: [
      {
        id: 'basic-forms',
        title: 'Les bases des formulaires',
        content: `
          <h2>Création de formulaires</h2>
          <p>Les formulaires permettent de collecter des données utilisateur :</p>
          <pre><code>
          &lt;form action="/submit" method="post"&gt;
            &lt;label for="nom"&gt;Nom :&lt;/label&gt;
            &lt;input type="text" id="nom" name="nom" required&gt;
            
            &lt;label for="email"&gt;Email :&lt;/label&gt;
            &lt;input type="email" id="email" name="email" required&gt;
            
            &lt;button type="submit"&gt;Envoyer&lt;/button&gt;
          &lt;/form&gt;
          </code></pre>
        `,
        exercise: {
          instructions: 'Créez un formulaire d\'inscription avec nom, email et message',
          initialCode: '<!-- Créez votre formulaire ici -->\n',
          solution: `<form>
  <div>
    <label for="nom">Nom :</label>
    <input type="text" id="nom" name="nom" required>
  </div>
  
  <div>
    <label for="email">Email :</label>
    <input type="email" id="email" name="email" required>
  </div>
  
  <div>
    <label for="message">Message :</label>
    <textarea id="message" name="message" rows="4"></textarea>
  </div>
  
  <button type="submit">Envoyer</button>
</form>`
        }
      }
    ]
  }
];