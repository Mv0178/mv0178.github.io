export const javascriptModules = [
  {
    id: 'basics',
    title: 'Les bases de JavaScript',
    description: 'Découvrez les concepts fondamentaux de JavaScript',
    lessons: [
      {
        id: 'introduction',
        title: 'Introduction à JavaScript',
        content: `
          <h2>Qu'est-ce que JavaScript ?</h2>
          <p>JavaScript est un langage de programmation qui permet de rendre les pages web interactives.</p>
          <ul>
            <li>Variables et types de données</li>
            <li>Opérateurs</li>
            <li>Structures de contrôle</li>
          </ul>

          <h3>Votre premier script</h3>
          <pre><code>
          // Afficher un message
          console.log('Bonjour le monde !');

          // Variables
          let nom = 'Alice';
          const age = 15;
          </code></pre>
        `,
        exercise: {
          instructions: 'Créez des variables pour stocker vos informations',
          initialCode: '// Créez vos variables ici\n',
          solution: `let prenom = 'Votre prénom';
let age = 15;
let estEtudiant = true;

console.log('Je m\'appelle ' + prenom);
console.log('J\'ai ' + age + ' ans');`
        }
      }
    ]
  },
  {
    id: 'functions',
    title: 'Fonctions et Événements',
    description: 'Maîtrisez les fonctions et la gestion des événements',
    lessons: [
      {
        id: 'functions-basics',
        title: 'Les fonctions',
        content: `
          <h2>Création de fonctions</h2>
          <p>Les fonctions permettent de regrouper du code réutilisable :</p>
          <pre><code>
          function direBonjour(nom) {
            return 'Bonjour ' + nom + ' !';
          }

          // Utilisation
          console.log(direBonjour('Alice'));
          </code></pre>
        `,
        exercise: {
          instructions: 'Créez une fonction qui calcule la moyenne de deux nombres',
          initialCode: '// Écrivez votre fonction ici\n',
          solution: `function calculerMoyenne(a, b) {
  return (a + b) / 2;
}

// Test de la fonction
console.log(calculerMoyenne(10, 20)); // Affiche 15`
        }
      }
    ]
  }
];