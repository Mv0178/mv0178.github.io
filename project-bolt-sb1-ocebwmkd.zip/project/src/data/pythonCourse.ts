export const pythonModules = [
  {
    id: 'basics',
    title: 'Les bases de Python',
    description: 'Découvrez les concepts fondamentaux de la programmation avec Python',
    lessons: [
      {
        id: 'introduction',
        title: 'Introduction à Python',
        content: `
          <h2>Qu'est-ce que Python ?</h2>
          <p>Python est un langage de programmation populaire créé par Guido van Rossum. Il est connu pour :</p>
          <ul>
            <li>Sa simplicité et sa lisibilité</li>
            <li>Sa grande communauté</li>
            <li>Sa polyvalence</li>
          </ul>
        `,
      },
      {
        id: 'variables',
        title: 'Variables et types de données',
        content: `
          <h2>Les variables en Python</h2>
          <p>Une variable est un conteneur pour stocker des données :</p>
          <pre><code>
          # Création de variables
          age = 15
          nom = "Alice"
          note = 18.5
          </code></pre>
        `,
        exercise: {
          instructions: 'Créez une variable "message" contenant votre nom et affichez-la',
          initialCode: '# Écrivez votre code ici\n',
          solution: 'message = "Votre nom"\nprint(message)'
        }
      }
    ]
  },
  {
    id: 'control-flow',
    title: 'Structures de contrôle',
    description: 'Apprenez à contrôler le flux de votre programme',
    lessons: [
      {
        id: 'conditions',
        title: 'Les conditions (if, else)',
        content: `
          <h2>Les conditions en Python</h2>
          <p>Les conditions permettent d'exécuter différents blocs de code selon une condition :</p>
          <pre><code>
          age = 15
          if age >= 18:
              print("Majeur")
          else:
              print("Mineur")
          </code></pre>
        `,
        exercise: {
          instructions: 'Écrivez un programme qui vérifie si un nombre est positif ou négatif',
          initialCode: 'nombre = 42\n# Écrivez votre code ici\n',
          solution: 'if nombre > 0:\n    print("Positif")\nelse:\n    print("Négatif")'
        }
      }
    ]
  }
];